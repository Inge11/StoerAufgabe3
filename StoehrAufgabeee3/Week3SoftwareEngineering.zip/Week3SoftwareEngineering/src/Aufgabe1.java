import java.util.Arrays;

public class Aufgabe1 {



    public int maxElementFinder(int[] testArray) {
        int[] compareArray = new int[testArray.length];
        Arrays.sort(compareArray);
        return compareArray[compareArray.length-1];

    }


}
