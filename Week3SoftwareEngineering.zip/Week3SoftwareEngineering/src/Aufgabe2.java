public class Aufgabe2 { // alle Teilaufgaben lassen sich durch abänderung der Arrays realisieren!
    String[] eins=new String[]{"I","IV","V","IX","X","XL","L","XC","C","CD","D","CM","M"};
    int[] zwei=new int[]{1,4,5,9,10,40,50,90,100,400,500,900,1000};

    String numToRom(int m){
        String res="";
        int i=zwei.length-1;
        do{

            if(((m-zwei[i])>0)){
                m-=zwei[i];
                res+=eins[i];
            }else{
                i-=1;
            }

        }while(i>=0);
        return res;
    }
}
